#include<iostream>
using namespace std;
struct Node
{
    string title;
    double price;
    string edition;
    int pages;
    Node* next;
};
class Stack
{
private:
    Node* top;
public:
    Stack()
	{
        top = NULL;
    }
    void push(string t, double p, string e, int pg)
	{
        Node* newNode = new Node();
        newNode->title = t;
        newNode->price = p;
        newNode->edition = e;
        newNode->pages = pg;
        newNode->next = top;
        top = newNode;
        cout << "Pushed \"" << t << "\" into stack." << endl;
    }
    void pop()
	{
        if (top == NULL)
		{
            cout << "Stack Underflow! Cannot pop from an empty stack." << endl;
        } else {
            Node* temp = top;
            top = top->next;
            cout << "Popped \"" << temp->title << "\" from stack." << endl;
            delete temp;
        }
    }
    void peek()
	{
        if (top == NULL)
		{
            cout << "Stack is empty." << endl;
        }
		else
		{
		cout << "Top book: " << top->title << ", Price: " << top->price << ", Edition: " << top->edition << ", Pages: " << top->pages << endl;
		}
    }
    bool isEmpty()
	{
        return (top == NULL);
    }
    void displayAll()
	{
        if (top == NULL)
		{
            cout << "Stack is empty." << endl;
            return;
        }
        Node* temp = top;
        while (temp != NULL)
		{
            cout << "Title: " << temp->title << ", Price: " << temp->price << ", Edition: " << temp->edition << ", Pages: " << temp->pages << endl;
            temp = temp->next;
        }
    }
    ~Stack()
	{
        while (top != NULL)
		{
            Node* temp = top;
            top = top->next;
            delete temp;
        }
    }
};
int main()
{
    Stack stack;
    string title, edition;
    double price;
    int pages;
    for (int i = 1; i <= 5; ++i)
	{
        cout << "\nEnter details for Book " << i << ":\n";
        cout << "Enter title: ";
        getline(cin, title);
        cout << "Enter price: ";
        cin >> price;
        cin.ignore();
        cout << "Enter edition: ";
        getline(cin, edition);
        cout << "Enter number of pages: ";
        cin >> pages;
        cin.ignore();
        stack.push(title, price, edition, pages);
    }
    cout << "\nTop book on the stack: " << endl;
    stack.peek();
    cout << "\nPopping 2 books...\n";
    stack.pop();
    stack.pop();
    cout << "\nRemaining books in the stack: " << endl;
    stack.displayAll();
    return 0;
}
