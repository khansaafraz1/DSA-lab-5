#include <iostream>
#include <string>
using namespace std;

class Inventory {
public:
    int serialNum;
    int manufactYear;
    int lotNum;
    Inventory* next;

    Inventory(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
        next = NULL;
    }
};

class InventoryStack {
private:
    Inventory* top;

public:
    InventoryStack() { top = NULL; }

    void push(int s, int y, int l) {
        Inventory* newNode = new Inventory(s, y, l);
        newNode->next = top;
        top = newNode;
        cout << "Part added: Serial Number " << s << endl;
    }

    void pop() {
        if (isEmpty()) {
            cout << "Stack Underflow! No parts to pop.\n";
            return;
        }
        Inventory* temp = top;
        cout << "Popped part - Serial Number: " << top->serialNum << ", Year: " << top->manufactYear << ", Lot Number: " << top->lotNum << endl;
        top = top->next;
        delete temp;
    }

    void peek() {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Top part - Serial Number: " << top->serialNum << ", Year: " << top->manufactYear << ", Lot Number: " << top->lotNum << endl;
    }

    bool isEmpty() {
        return top == NULL;
    }

    void display() {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Parts in inventory:\n";
        Inventory* temp = top;
        while (temp != NULL) {
            cout << "Serial Number: " << temp->serialNum << ", Year: " << temp->manufactYear << ", Lot Number: " << temp->lotNum << endl;
            temp = temp->next;
        }
    }
};

int main() {
    InventoryStack stack;
    int choice, serial, year, lot;

    do {
        cout << "\nInventory Management:\n1. Add Part\n2. Remove Part\n3. View Top Part\n4. Display Inventory\n5. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter Serial Number, Manufacturing Year, and Lot Number: ";
            cin >> serial >> year >> lot;
            stack.push(serial, year, lot);
            break;
        case 2:
            stack.pop();
            break;
        case 3:
            stack.peek();
            break;
        case 4:
            stack.display();
            break;
        case 5:
            cout << "Exiting program...\n";
            break;
        default:
            cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
