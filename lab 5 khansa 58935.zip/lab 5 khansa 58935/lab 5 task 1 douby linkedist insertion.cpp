#include<iostream>
using namespace std;
struct Node{
	int data;
	Node* next;
	Node* prv;
	Node(int data){
		this->data = data;
		this->next= NULL;
		this->prv = NULL;
	}
};
Node* head = NULL;
void addAtBegining(int data){
	Node* newNode = new Node(data);
	if(head==NULL){
		head = newNode;
	}
	else{
		newNode->next = head;
		head->prv = newNode;
		head = newNode; 
	}
}
void addAtMiddle(int data, int p){
	if(p==0){
	 addAtBegining(data);
	 return;	
	}
	Node* newNode = new Node(data);
	Node* temp = head;
	for(int i =0;i<p-1;i++){
		temp = temp->next;
		if(temp==NULL){
			cout<<"Position out of bound"<<endl;
			return;
		}
	}
	newNode->next = temp->next;
	newNode->prv = temp;
	if(temp->next!=NULL){
		temp->next->prv = newNode;
	}
	temp->next = newNode;
}
void display(){
	if(head==NULL){
		cout<<"list is empty:"<<endl;
		return;
	}
	Node* temp = head;
	while(temp!=NULL){
		cout<<temp->data<<"<->";
		temp= temp->next;
	}
	cout<<"NULL"<<endl;
}
int main(){
	int choice,value,p;
	while(true){
	
	cout<<"Menu:"<<endl;
	cout<<"01: Add at begining:"<<endl;
	cout<<"02: Add at position 45"<<endl;
	cout<<"03: Display"<<endl;
	cout<<"Enter your choice:"<<endl;
	cin>>choice;
	switch(choice){
		
		case 1:
		cout<<"Enter you value:"<<endl;
		cin>>value;
		addAtBegining(value);
		break;
		case 2:
		cout<<"Enter you value to insert at position 45:"<<endl;
		cin>>value;
		cout<<"Enter your position:"<<endl;
		cin>>p;
		addAtMiddle(value,p);
		break;
		case 3:
			display();
			break;
		default:
		cout<<"Invalid choice: try again"<<endl;	
	}
}
return 0;
}
