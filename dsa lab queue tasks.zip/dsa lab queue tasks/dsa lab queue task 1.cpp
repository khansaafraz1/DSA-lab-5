#include<iostream>
using namespace std;
struct Applicant{
	int id;
	float height;
	float weight;
	float vision;
	string teststatus;
	Applicant* next;
};
class ApplicantQueue{
	public:
		Applicant* front;
		Applicant* rear;
	ApplicantQueue(){
			front=NULL;
			rear=NULL;
		}
		bool isEmpty(){
			return front==NULL;
		}
		void enqueue(int id,float h,float w,float v,string test){
			Applicant* newNode=new Applicant();
			newNode->id=id;
			newNode->height=h;
			newNode->weight=w;
			newNode->vision=v;
			newNode->teststatus=test;
			newNode->next=NULL;
			if(rear==NULL){
				front=rear=newNode;
			}else{
				rear->next=newNode;
				rear=newNode;
			}
			cout<<"Enqueued applicant id:"<<id<<endl;
		}
		void dequeue(){
			if(isEmpty()){
				cout<<"Queue is empty.\n";
				return;
			}
			Applicant* temp=front;
			cout<<"Applicant id "<< temp->id <<"has dequeued"<<endl;
			front=front->next;
			delete temp;
		}
		void removesecondapplicant(){
			if(front==NULL|| front->next==NULL){
				cout<<"Not enough applicant.\n";
				return;
			}
			Applicant* temp=front->next;
			cout<<"Applicant id "<<temp->id<<" removed.\n";
			front->next=temp->next;
			delete temp;
		}
		void display(){
			if(isEmpty()){
				cout<<"Queue is empty./n";
				return;
			}
		
			Applicant* temp=front;
			while(temp!=NULL){
				cout<<" ID:"<<temp->id<< " Height:"<<temp->height<<" Weight: "<<temp->weight<<" Vision:"
				<<temp->vision<<" ,Test Status:"<<temp->teststatus<<"\n";
				temp=temp->next;
			}
			cout<<" \n";
		}
};
int main(){
	ApplicantQueue q;
	q.enqueue(101,5.8,70,6,"Waiting");
	q.enqueue(102,5.6,65,6.5,"Waiting");
	q.enqueue(103,5.9,68,6.2,"Waiting");
	q.enqueue(104,5.7,72,6.1,"Waiting");
	q.enqueue(105, 6.0, 75, 5.9,"Waiting");
	q.enqueue(106, 5.5, 66, 6.0,"Waiting");
	q.enqueue(107, 5.8, 74, 6.3,"Waiting");
	q.display();
	
	q.removesecondapplicant();
	q.display();
	
	q.dequeue();
	q.display();
	
	q.enqueue(108,6.1,78,6.4,"Waiting");
	q.display();
	
	return 0;
		
}
