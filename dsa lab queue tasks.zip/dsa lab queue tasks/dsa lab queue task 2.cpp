#include<iostream>
using namespace std;
struct Node{
	int truckid;
	Node* next;
};
class Queue{
	public:
	Node* front;
	Node* rear;
	Queue(){
		front=NULL;
		rear=NULL;
	}
	bool isEmpty(){
		return front==NULL;
	}
	void Entergarage(int truckid){
		Node* newNode=new Node();
		newNode->truckid=truckid;
		newNode->next=NULL;
		if(rear==NULL){
			front=rear=newNode;
		}
		else{
			rear->next=newNode;
			rear=newNode;
		}
		cout<<"Truck with id "<<truckid<<" is on the road\n";
	}
	void exitgarage(){
		if(isEmpty()){
			cout<<"Road is empty"<<endl;
			return;
		}
		Node* temp=front;
		int id=temp->truckid;
		front=front->next;
		delete temp;
		cout<<"Truck with id "<<id<<" left the road.\n";
	}
	void showtruck(){
		if(isEmpty()){
			cout<<"Road is empty.\n"<<endl;
			return;
		}
		cout<<"Trucks on road:";
		Node*temp=front;
		while(temp!=NULL){
			cout<< temp->truckid;
			temp=temp->next;
		}
		cout<<endl;
	}
};
int main(){
	Queue q;
	q.Entergarage(101);
	q.Entergarage(102);
	q.Entergarage(103);
	q.showtruck();
	
	q.exitgarage();
	q.showtruck();
	
	q.Entergarage(104);
	q.showtruck();
	
	q.exitgarage();
	q.showtruck();
	q.exitgarage();
	q.exitgarage();
	q.showtruck();
	
	return 0;
	
}
