#include <iostream>
using namespace std;

class Node {
public:
    string title;
    double price;
    int edition;
    int pages;
    Node* next;

    Node(string t, double p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};

class BookStack {
private:
    Node* top;

public:
    BookStack() { top = NULL; }

    void push(string t, double p, int e, int pg) {
        Node* newNode = new Node(t, p, e, pg);
        newNode->next = top;
        top = newNode;
        cout << "Book pushed: " << t << endl;
    }

    void pop() {
        if (isEmpty()) {
            cout << "Stack Underflow! No books to pop.\n";
            return;
        }
        Node* temp = top;
        cout << "Popped book: " << top->title << endl;
        top = top->next;
        delete temp;
    }

    void peek() {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Top book - Title: " << top->title << ", Price: " << top->price
             << ", Edition: " << top->edition << ", Pages: " << top->pages << endl;
    }

    bool isEmpty() {
        return top == NULL;
    }

    void display() {
        if (isEmpty()) {
            cout << "Stack is empty!\n";
            return;
        }
        cout << "Books in stack:\n";
        Node* temp = top;
        while (temp != NULL) {
            cout << "Title: " << temp->title << ", Price: " << temp->price
                 << ", Edition: " << temp->edition << ", Pages: " << temp->pages << endl;
            temp = temp->next;
        }
    }
};

int main() {
    BookStack stack;

   
    stack.push("Book A", 25.99, 1, 300);
    stack.push("Book B", 30.50, 2, 250);
    stack.push("Book C", 15.75, 3, 400);
    stack.push("Book D", 40.99, 4, 500);
    stack.push("Book E", 22.30, 5, 350);

    
    cout << "\nTop element of the stack:\n";
    stack.peek();

   
    cout << "\nPopping 2 books:\n";
    stack.pop();
    stack.pop();


    cout << "\nRemaining books in the stack:\n";
    stack.display();

    return 0;
}
